﻿namespace OutBoundMail.API.Models
{
    public class EmailTemplate
    {
        public string Id { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }
}
